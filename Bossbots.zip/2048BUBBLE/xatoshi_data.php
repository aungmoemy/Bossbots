<?php
# config by : muh maulana
# channel : xatoshi lanzz
# telegram : @xatoshilanzz & @cxatoshi

$user_id = "xxxxx";
?>

<?php

//MASUKAN USER_GUID & GAID MILIK KALIAN!!!
$user_guid = "xxxxxxxx";
$gaid = "xxxxxxx";
